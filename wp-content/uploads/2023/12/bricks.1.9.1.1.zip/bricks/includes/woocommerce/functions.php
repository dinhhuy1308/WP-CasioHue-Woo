<?php
function woocommerce_output_content_wrapper() {
	echo '<div id="brx-content">';
}

function woocommerce_output_content_wrapper_end() {
	echo '</div>';
}
