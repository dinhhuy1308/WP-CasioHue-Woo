<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Empty file to avoid the deprecated message for sidebar.
